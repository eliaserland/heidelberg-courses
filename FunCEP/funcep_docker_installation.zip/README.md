# FUNCEP with docker


Following requirements needed to be met and installed

* git
* docker
* Paraview (for display)
* Sufficient space on harddrive

There are  two ways to install this  docker image, simply pulling it via network
or running the build process.

## running (and downloading prebuilt image)  on  mac and windows

Simply execute 
```
chmod u+x  install_internet.sh
./install_internet.sh
```

## building under mac and linux

Please check if all files are there:

- `build_fftw3.sh` contains the build instruction for fftw3
- `build_hdf.sh` contains build for hdf5
- `docker-compose.yml` contains the infos about the volume
- `Dockerfile` build instructions for the image
- `installer.sh` installer for dune provided by P. Bastian
- `install.sh` initial installer.

```sh
chmod u+x install.sh
./install.sh
```
If the initial compile did not work (I only experienced that on mac), just log in to the shell using:

```sh
docker-compose run dev bash
```

and run `make` in dune-funcep/build-cmake

```sh
cd dune-funcep/build-cmake
make
```
### Running

use the following command to open a shell

```sh
docker-compose run dev bash
```

Then you can use the shell and do the following (for compiling). Editing is done in dune-funcep folder, changes are sync'ed to your local drive you can also use an other editor on your host system.

```
cd dune-funcep/build-cmake
make
```

### Displaying paraview files

If you want to display files, you can open them on the host system, they are located then in the `dune-funcep/build-cmake` folder.

## Ammendum usage under windows

There is an extra file
- `docker-compose.windows.yml` contains the infos about the volume under windows
- `windows_reinstall.sh` reinstall file for usage under windows/docker.

1. Install Docker https://docs.docker.com/docker-for-windows/install/, please note their remarks about home edition! Restart if necessary. 
2. Disable wsl 2 support and use the old hyperv version in the settings of docker desktop (this is a fix for the mounted volume)
3. (Download and install git https://git-scm.com/downloads)
4. start an powershell:

```
docker-compose -f .\docker-compose.windows.yml build # this can be skipped, if you have a decent internet connection
docker-compose -f .\docker-compose.windows.yml run dev bash
```

Then in the shell run

```
./windows_reinstall.sh
```

Then you can use the shell and do the following (for compiling). Editing is done in dune-funcep folder, changes are sync'ed to your local drive you can also use an other editor on your host system.

```
cd dune-funcep/build-cmake
make
```

If you have any question, send me an email: reinstaedtler (at) stud.uni-heidelberg.de