git clone https://parcomp-git.iwr.uni-heidelberg.de/Teaching/dune-funcep.git
chmod u+x *.sh
docker-compose build
docker-compose run dev sh -c "GXX_OPTS=\"-march=native -g -O3 -std=c++14\" MAKEFLAGS=\"-j$(nproc)\" CMAKE_FLAGS=\"-DHDF5_ROOT=/hdf5 -DFFTW3_ROOT_DIR=/fftw3  \" ./dune-common/bin/dunecontrol all --opts=release.opts --only=dune-funcep"
