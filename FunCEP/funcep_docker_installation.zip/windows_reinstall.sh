#!/bin/bash
apt update
apt install nano
rm -rf dune-funcep/*
rm -rf dune-funcep
git clone https://parcomp-git.iwr.uni-heidelberg.de/Teaching/dune-funcep.git
sh -c "GXX_OPTS=\"-march=native -g -O3 -std=c++14\" CMAKE_FLAGS=\"-DHDF5_ROOT=/hdf5 -DFFTW3_ROOT_DIR=/fftw3  \" ./dune-common/bin/dunecontrol all --opts=release.opts --only=dune-funcep"