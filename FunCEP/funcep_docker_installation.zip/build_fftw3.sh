#!/bin/bash
# build fftw3
install_fftw3 ()
{
    FFTWVERSION=3.3.8
    pushd $EXTERNAL_HOME
    mkdir -p tarballs
    pushd tarballs
    wget http://www.fftw.org/fftw-$FFTWVERSION.tar.gz
    tar zxvf fftw-$FFTWVERSION.tar.gz
    pushd fftw-$FFTWVERSION
    ( ./configure CC=$CC MPICC=$MPICC CFLAGS="$CXXFLAGS" --enable-mpi --enable-shared=yes --prefix=$EXTERNAL_HOME/fftw3 && make && make install) || exit $?
    popd
    rm -rf fftw-$FFTWVERSION
    popd
}
install_fftw3