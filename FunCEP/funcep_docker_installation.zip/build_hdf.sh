#!/bin/bash
# build hdf5 with mpi support
install_hdf5 ()
{
    pushd $EXTERNAL_HOME
    mkdir -p tarballs
    pushd tarballs
#    HDF5VERSION=1.8.17
#    curl -O http://www.hdfgroup.org/ftp/HDF5/current/src/hdf5-$HDF5VERSION.tar.gz
    MAJOR=1.12
    MINOR=0
    HDF5VERSION=$MAJOR.$MINOR
    wget http://www.hdfgroup.org/ftp/HDF5/releases/hdf5-$MAJOR/hdf5-$HDF5VERSION/src/hdf5-$HDF5VERSION.tar.gz
    tar zxvf hdf5-$HDF5VERSION.tar.gz
    pushd hdf5-$HDF5VERSION
    ( ./configure CC=$MPICC --enable-parallel --enable-static --prefix=$EXTERNAL_HOME/hdf5 && make -j16 && make install) || exit $?
    popd
    rm -rf hdf5-$HDF5VERSION
    popd
}
install_hdf5